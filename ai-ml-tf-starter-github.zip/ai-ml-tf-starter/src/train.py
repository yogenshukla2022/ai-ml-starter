import argparse
from pathlib import Path
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn import datasets

def load_iris():
    iris = datasets.load_iris(as_frame=True)
    df = iris.frame
    df = df.rename(columns={"target": "species"})
    return df

def train_and_save(out_path: Path, epochs: int = 5, batch_size: int = 8) -> float:
    df = load_iris()
    X = df.drop(columns=["species"]).values.astype("float32")
    y = tf.keras.utils.to_categorical(df["species"].values, num_classes=3)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(16, activation="relu", input_shape=(4,)),
        tf.keras.layers.Dense(16, activation="relu"),
        tf.keras.layers.Dense(3, activation="softmax"),
    ])
    model.compile(optimizer="adam", loss="categorical_crossentropy", metrics=["accuracy"])
    model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, verbose=0)
    loss, acc = model.evaluate(X_test, y_test, verbose=0)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    model.save(out_path)
    print(f"Saved TensorFlow model to {out_path} with accuracy={acc:.3f}")
    return acc

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, default=Path("models/tf_model"))
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch_size", type=int, default=8)
    args = parser.parse_args()
    train_and_save(args.out, args.epochs, args.batch_size)
