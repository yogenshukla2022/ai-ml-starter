import argparse
from pathlib import Path
import numpy as np
import tensorflow as tf

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", type=Path, default=Path("models/tf_model"))
    parser.add_argument("--sepal_length", type=float, required=True)
    parser.add_argument("--sepal_width", type=float, required=True)
    parser.add_argument("--petal_length", type=float, required=True)
    parser.add_argument("--petal_width", type=float, required=True)
    args = parser.parse_args()
    model = tf.keras.models.load_model(args.model)
    X = np.array([[args.sepal_length, args.sepal_width, args.petal_length, args.petal_width]])
    pred = np.argmax(model.predict(X), axis=1)[0]
    print(f"Predicted class: {pred}")
