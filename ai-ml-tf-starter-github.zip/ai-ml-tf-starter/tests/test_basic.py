from pathlib import Path
from src.train import train_and_save

def test_training(tmp_path: Path):
    out = tmp_path / "tf_model"
    acc = train_and_save(out, epochs=2, batch_size=4)
    assert out.exists()
    assert 0.5 <= acc <= 1.0
